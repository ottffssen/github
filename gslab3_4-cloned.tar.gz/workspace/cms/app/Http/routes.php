<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

use App\Books;
use Illuminate\Http\Request;

Route::get('/','BooksController@index');
Route::post('/books','BooksController@store');
Route::post('/booksedit/{books}','BooksController@edit');
Route::post('/books/update','BooksController@update');
Route::delete('/book/{book}','BooksController@destroy');
