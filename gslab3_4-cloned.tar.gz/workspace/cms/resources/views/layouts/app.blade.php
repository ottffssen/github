<!doctype html>
<html lang="en">
<head>
    <title>Book List</title>
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-default">
            
        </nav>
    </div>
    
    @yield('content')
</body>
</html>